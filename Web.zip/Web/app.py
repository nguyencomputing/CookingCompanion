from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import openai
from functools import wraps
import os

# DO NOT MODIFY THE FOLLOWING LINE (keep your given API key exactly as-is)
openai.api_key = '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'

app = Flask(__name__)
# This line is essential for session security.
app.secret_key = os.urandom(24)

# In-memory user "database" for demonstration purposes
users = {}  # keys: usernames; values: passwords

def ask_gpt(messages, model="gpt-3.5-turbo", max_tokens=1000, temperature=0.7):
    """
    Calls the OpenAI ChatCompletion API with the provided messages.
    Returns the assistant's response as a string.
    """
    response = openai.chat.completions.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return response.choices[0].message.content.strip()

def login_required(f):
    """Decorator to protect routes that require login."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ----- Routes for Login/Signup/Logout -----

@app.route('/')
@login_required
def index():
    # If the user has not yet submitted their preferences, redirect them to the preferences page.
    if 'preferences' not in session:
        return redirect(url_for('preferences'))
    # Clear any previous conversation for a fresh start (or load previous history)
    session['conversation'] = []
    return render_template('chat.html', username=session['username'], preferences=session['preferences'])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
         username = request.form['username']
         password = request.form['password']
         if username in users and users[username] == password:
             session['username'] = username
             # Redirect to the preferences page after login
             return redirect(url_for('preferences'))
         else:
             flash("Invalid username or password!")
             return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
         username = request.form['username']
         password = request.form['password']
         if username in users:
             flash("Username already exists! Please choose another.")
             return redirect(url_for('signup'))
         users[username] = password
         flash("Account created successfully! Please log in.")
         return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('preferences', None)
    flash("Logged out successfully.")
    return redirect(url_for('login'))

# ----- New: Preferences Route -----
@app.route('/preferences', methods=['GET', 'POST'])
@login_required
def preferences():
    if request.method == 'POST':
        # Collect preferences from form submission
        prefs = {}
        prefs["allergies"] = request.form.get("allergies", "")
        # For cuisine, check if the user selected one of the multiple-choice options or entered an 'other'
        cuisine_choice = request.form.get("cuisine_choice", "")
        cuisine_other = request.form.get("cuisine_other", "")
        prefs["cuisine"] = cuisine_other if cuisine_choice == "other" and cuisine_other.strip() != "" else cuisine_choice

        # Similarly for difficulty
        difficulty_choice = request.form.get("difficulty_choice", "")
        difficulty_other = request.form.get("difficulty_other", "")
        prefs["difficulty"] = difficulty_other if difficulty_choice == "other" and difficulty_other.strip() != "" else difficulty_choice

        # For time
        time_choice = request.form.get("time_choice", "")
        time_other = request.form.get("time_other", "")
        prefs["time"] = time_other if time_choice == "other" and time_other.strip() != "" else time_choice

        # For dietary restrictions
        dietary_choice = request.form.get("dietary_choice", "")
        dietary_other = request.form.get("dietary_other", "")
        prefs["dietary_restrictions"] = dietary_other if dietary_choice == "other" and dietary_other.strip() != "" else dietary_choice

        # Store preferences in session for later use (e.g., to pass to the system prompt)
        session['preferences'] = prefs
        # After saving preferences, go to the chat interface.
        return redirect(url_for('index'))
    return render_template('preferences.html')

# ----- Chat Endpoint -----

@app.route('/chat', methods=['POST'])
@login_required
def chat():
    user_input = request.form['message']
    # Retrieve the conversation from session; if none, initialize as empty list.
    conversation = session.get('conversation', [])

    # Append the user's message
    conversation.append({"role": "user", "content": user_input})

    # Build a system prompt that now also includes the user's preferences
    system_prompt = (
        "You are a personal and professional cooking companion with deep expertise "
        "in customized recipes. The user preferences are as follows:\n"
    )
    if 'preferences' in session:
        prefs = session['preferences']
        for k, v in prefs.items():
            system_prompt += f"{k.capitalize()}: {v}\n"
    system_prompt += (
        "Provide stable, thorough, reasonable, and consistent instructions. "
        "If the recipe lacks a necessary ingredient, regenerate a new recipe!"
    )

    # Insert or update the system prompt at the beginning of the conversation.
    if not conversation or conversation[0].get("role") != "system":
        conversation.insert(0, {"role": "system", "content": system_prompt})
    else:
        conversation[0]["content"] = system_prompt

    # Call OpenAI to get the assistant's response.
    assistant_response = ask_gpt(conversation)
    conversation.append({"role": "assistant", "content": assistant_response})

    # Save the updated conversation in session.
    session['conversation'] = conversation

    # Return the assistant's response as JSON.
    return jsonify({"response": assistant_response})

if __name__ == '__main__':
    app.run(debug=True)
